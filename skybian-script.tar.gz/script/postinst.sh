#!/bin/bash
/usr/bin/skybian-chrootconfig
