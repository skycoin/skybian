#!/bin/bash
#skybian post install script ; executed by dpkg upon package installation or updates
/usr/bin/skybian-chrootconfig
