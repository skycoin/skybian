#!/bin/bash
#set envs here
SKYBIAN=true
VPNSERVER=1
