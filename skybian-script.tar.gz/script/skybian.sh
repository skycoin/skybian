#!/bin/bash
#set envs here
SKYBIAN=true
VPNSERVER=true
