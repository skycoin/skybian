#!/bin/bash
#set envs here
export SKYBIAN=true
export VPNSERVER=1
